﻿namespace TP3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MnuRes = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuArt = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuConArt = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuRegArt = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuRes,
            this.MnuArt});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(227, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MnuRes
            // 
            this.MnuRes.Name = "MnuRes";
            this.MnuRes.Size = new System.Drawing.Size(76, 20);
            this.MnuRes.Text = "Resultados";
            this.MnuRes.Click += new System.EventHandler(this.MnuRes_Click);
            // 
            // MnuArt
            // 
            this.MnuArt.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuConArt,
            this.MnuRegArt});
            this.MnuArt.Name = "MnuArt";
            this.MnuArt.Size = new System.Drawing.Size(66, 20);
            this.MnuArt.Text = "Artículos";
            // 
            // MnuConArt
            // 
            this.MnuConArt.Name = "MnuConArt";
            this.MnuConArt.Size = new System.Drawing.Size(121, 22);
            this.MnuConArt.Text = "Consulta";
            this.MnuConArt.Click += new System.EventHandler(this.MnuConArt_Click);
            // 
            // MnuRegArt
            // 
            this.MnuRegArt.Name = "MnuRegArt";
            this.MnuRegArt.Size = new System.Drawing.Size(121, 22);
            this.MnuRegArt.Text = "Registro";
            this.MnuRegArt.Click += new System.EventHandler(this.MnuRegArt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(227, 150);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Menú";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MnuRes;
        private System.Windows.Forms.ToolStripMenuItem MnuArt;
        private System.Windows.Forms.ToolStripMenuItem MnuConArt;
        private System.Windows.Forms.ToolStripMenuItem MnuRegArt;
    }
}

