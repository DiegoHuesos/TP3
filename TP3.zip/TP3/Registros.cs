﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP3
{
    public partial class Registros : Form
    {
        //variables de clase
        Comunes comunes = new Comunes();
        SistemaCongresosEntities1 context = new SistemaCongresosEntities1();
        BindingSource regBS = new BindingSource();
        DataSet dsArt = new DataSet(), dsCong = new DataSet(), dsA = new DataSet(), dsC = new DataSet();
        GestorBD.GestorBD GestorBD;
        public Registros()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string art = cbArts.SelectedItem.ToString(),
                cong = cbCongresos.SelectedItem.ToString(),
                fecha = dateTimePicker1.Value.ToShortDateString(),
                horario = txHorario.Text,
                ponente = txNombre.Text, cadSql1, cadSql2, cadSql3;
            string[] stSplit = fecha.Split('/');
            fecha = stSplit[2] + '/' + stSplit[1] + '/' + stSplit[0];
            try
            {
                string [] horas = horario.Split('-'), hoMin;
                string ho, min;
                foreach (string h in horas)
                {
                    hoMin = h.Split(':');
                    if (hoMin[0].CompareTo("00") < 0 || hoMin[0].CompareTo("23") > 0 || hoMin[1].CompareTo("00") < 0 || hoMin[1].CompareTo("59") > 0)
                        throw new FormatException();
                }//foreach
                cadSql1 = $"select idArt from Artículo where nombre = '{art}'";
                cadSql2 = $"select idCon from Congreso where nomCon = '{cong}'";
                GestorBD.consBD(cadSql1, dsA, "Artículo");
                GestorBD.consBD(cadSql2, dsC, "Congreso");
                string idA, idC;
                idA = dsA.Tables["Artículo"].Rows[0][0].ToString();
                idC = dsC.Tables["Congreso"].Rows[0][0].ToString();
                

                cadSql3 = $"insert into Presenta {idA}, {idC}, '{ponente}', '{fecha}', '{horario}'";
                MessageBox.Show("Alta efectuada correctamente");
            }//try
            catch(Exception ex){
                MessageBox.Show("Por favor inserte datos válidos\n" + ex.ToString());
            }
        }

        private void Registros_Load(object sender, EventArgs e)
        {
            GestorBD = new GestorBD.GestorBD("SQLNCLI11", "DESKTOP-I4BI3PH",
            "sa", "sqladmin", "SistemaCongresos");
            string cadSql1 = "select nombre from Artículo";
            GestorBD.consBD(cadSql1, dsArt,"Artículo");
            comunes.cargaCombo(cbArts, dsArt, "Artículo", "nombre");
            cbArts.SelectedIndex = 0;
            string cadSql2 = "select nomCon from Congreso";
            GestorBD.consBD(cadSql2, dsCong, "Congreso");
            comunes.cargaCombo(cbCongresos,dsCong,"Congreso","nomCon");
            cbCongresos.SelectedIndex = 0;
        }
    }
}
