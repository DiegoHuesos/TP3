﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP3
{
    public partial class Resultados : Form
    {
        //variables de clase
        SistemaCongresosEntities1 context = new SistemaCongresosEntities1();
        BindingSource ResBS = new BindingSource();
        DataSet dsCons = new DataSet();
        GestorBD.GestorBD GestorBD;
        string nomA, fecha;
        bool cons = false;
        public Resultados()
        {
            InitializeComponent();
        }

        public Resultados(string n, string f)
        {
            nomA = n;
            fecha = f;
            cons = true;
            InitializeComponent();
        }//builder2

        private void Resultados_Load(object sender, EventArgs e)
        {
            if (cons)
            {
                consultaArts(fecha, nomA);
            }//if
        }

        public void consultaArts(string date, string autor)
        {
            GestorBD = new GestorBD.GestorBD("SQLNCLI11", "DESKTOP-I4BI3PH",
            "sa", "sqladmin", "SistemaCongresos");
            string cadSql = String.Format("select Artículo.nombre as Artículo, Autor.nombre as Coautor, Institución.nombre as Trabaja_en, Congreso.nomCon as Congreso, Presenta.fecha as Fecha_Presentación from Autor inner join Escribe on Autor.idAut = Escribe.idAut inner join Artículo on Artículo.idArt = Escribe.idArt inner join Trabaja on Trabaja.idAut = Autor.idAut inner join Institución on Institución.idInst = Trabaja.idInst inner join Presenta on Presenta.idArt = Artículo.idArt inner join Congreso on Congreso.idCon = Presenta.idCon where Escribe.idArt in (select Artículo.idArt as id from Artículo  inner join Presenta on Artículo.idArt = Presenta.idArt  inner join Escribe on Escribe.idArt = Artículo.idArt  inner join Autor on Autor.idAut = Escribe.idAut  where Autor.nombre = '{0}' and Presenta.fecha >= '{1}') ", autor, date);
            GestorBD.consBD(cadSql, dsCons, "Respuestas");
            DG1.DataSource = dsCons.Tables["Respuestas"];
        }//method
    }//class
}//namespace
