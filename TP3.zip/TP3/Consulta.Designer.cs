﻿namespace TP3
{
    partial class Consulta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbAutores = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MnuRes = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuArt = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuConArt = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuRegArt = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbAutores
            // 
            this.cbAutores.FormattingEnabled = true;
            this.cbAutores.Location = new System.Drawing.Point(140, 58);
            this.cbAutores.Name = "cbAutores";
            this.cbAutores.Size = new System.Drawing.Size(121, 21);
            this.cbAutores.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(416, 58);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombre del autor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(352, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "A partir de:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(103, 128);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "Buscar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuRes,
            this.MnuArt});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(649, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MnuRes
            // 
            this.MnuRes.Name = "MnuRes";
            this.MnuRes.Size = new System.Drawing.Size(76, 20);
            this.MnuRes.Text = "Resultados";
            this.MnuRes.Click += new System.EventHandler(this.MnuRes_Click);
            // 
            // MnuArt
            // 
            this.MnuArt.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuConArt,
            this.MnuRegArt});
            this.MnuArt.Name = "MnuArt";
            this.MnuArt.Size = new System.Drawing.Size(66, 20);
            this.MnuArt.Text = "Artículos";
            this.MnuArt.Click += new System.EventHandler(this.MnuArt_Click);
            // 
            // MnuConArt
            // 
            this.MnuConArt.Name = "MnuConArt";
            this.MnuConArt.Size = new System.Drawing.Size(180, 22);
            this.MnuConArt.Text = "Consulta";
            this.MnuConArt.Click += new System.EventHandler(this.MnuConArt_Click);
            // 
            // MnuRegArt
            // 
            this.MnuRegArt.Name = "MnuRegArt";
            this.MnuRegArt.Size = new System.Drawing.Size(180, 22);
            this.MnuRegArt.Text = "Registro";
            this.MnuRegArt.Click += new System.EventHandler(this.MnuRegArt_Click);
            // 
            // Consulta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 183);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.cbAutores);
            this.Name = "Consulta";
            this.Text = "Consulta";
            this.Load += new System.EventHandler(this.Consulta_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbAutores;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MnuRes;
        private System.Windows.Forms.ToolStripMenuItem MnuArt;
        private System.Windows.Forms.ToolStripMenuItem MnuConArt;
        private System.Windows.Forms.ToolStripMenuItem MnuRegArt;
    }
}