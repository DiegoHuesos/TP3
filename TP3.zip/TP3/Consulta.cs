﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP3
{
    public partial class Consulta : Form
    {
        //variables de clase
        static string autor = "", fecha = "";
        SistemaCongresosEntities1 context = new SistemaCongresosEntities1();
        BindingSource onBS = new BindingSource();
        DataSet dsCons = new DataSet();
        Comunes comunes = new Comunes();
        GestorBD.GestorBD GestorBD;
        public Consulta()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            autor = cbAutores.SelectedItem.ToString();
            fecha = dateTimePicker1.Value.ToShortDateString();
            string[] stSplit = fecha.Split('/');
            fecha = stSplit[2] + '/' + stSplit[1] + '/' + stSplit[0];
            Resultados r = new Resultados(autor, fecha);
            r.Show();
            this.Close();
            
        }//buttonMethod

        private void MnuArt_Click(object sender, EventArgs e)
        {

        }

        private void MnuConArt_Click(object sender, EventArgs e)
        {

        }

        private void MnuRegArt_Click(object sender, EventArgs e)
        {
            
        }

        private void MnuRes_Click(object sender, EventArgs e)
        {
            Resultados r = new Resultados();
            r.Show();
            this.Close();
        }

        private void Consulta_Load(object sender, EventArgs e)
        {
            try
            {
                //variables locales
                GestorBD = new GestorBD.GestorBD("SQLNCLI11", "DESKTOP-I4BI3PH",
                "sa", "sqladmin", "SistemaCongresos");
                string cadSql = "select nombre from Autor";
                GestorBD.consBD(cadSql, dsCons, "Autor");
                comunes.cargaCombo(cbAutores, dsCons, "Autor", "nombre");
                cbAutores.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }//load
    }
}
